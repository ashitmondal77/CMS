<?php
/**
 * Template for displaying search forms in Twenty Seventeen
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>


<form>
	<input type="text" class="search_box" placeholder="কী খুঁজতে চান?" name="s" /><button type="submit" class="search_button">
		<i class="fa fa-search" aria-hidden="true"></i>
	</button>

	<div onclick="closesearch()" class="search_close_button">
		<i class="fa fa-times search_close_button_icon_sizing" aria-hidden="true"></i>
	</div>
</form>