<?php global $prothom_alo; ?>
<?php
/**
 * The header for our theme
 * @package WordPress
 * @subpackage custom
 * @since my theme 1.0
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="UTF-8" />
	<meta charset="<?php bloginfo('charset'); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title><?php wp_title('-', true, 'right'); ?></title>
	<link rel="icon" href="<?php echo $prothom_alo['favicon_upload']['url'] ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head(); ?>
</head>

<body>

	<!---Nav Bar Start---->
	<div id="jkModal" class="jkmodal"></div>
		<div class="prothom_nav_ground">
			<div class="custom-container mobile_nav_poku">
				<div class="row">
					<div class="col-10  col-md-2 col-lg-2 mobile_logo_sizing">
						<div class="mobile_search_menu_ground">
							<i onclick="opensearch()" class="fa fa-search search_button_logo_sizing" aria-hidden="true"></i>
						</div>
						<a href="<?php home_ento(); ?>"><img src="<?php echo $prothom_alo['logo_upload']['url'] ?>" class="logo_sizing" alt="logo" /></a>
					</div>
					<div class="col-7  boot_dextop">
						<div id="dextop-menu" class="prothom_nav_dextop_menu_ground">
							<?php echo $prothom_alo['header_nav1'] ?>
							<!---Costom Option--->
						</div>
					</div>
					<div class="col-2 col-md-3 col-lg-3">
						<div class="meun_button_for_dxmo">
							<div class="spiypo">
								<i class="fa fa-bars meun_button_logo_sizeing" onclick="opennav()" id="open-button" aria-hidden="true"></i>
								<i style="display: none;" class="fa fa-times meun_button_logo_sizeing" onclick="closenav()" id="close-button" aria-hidden="true"></i>
							</div>
							<div class="all_menu_tittle device_hishowr_5">সব</div>
							<div class="nav-bordere"></div>
						</div>

						<div class="language_ground_for_dxt device_hishow_1"><a href="#">English</a></div>
						<div class="user_profile_gt device_hishow_2">
							<a id="mybtn1"><i class="fa fa-user-circle user_profile_logo_sizeing" aria-hidden="true"></i></a>
						</div>
						<div class="search_button_gt device_hishow_3">
							<i onclick="opensearch()" class="fa fa-search search_button_logo_sizeing" aria-hidden="true"></i>
						</div>
						<div class="user_profile_gt device_hishow_4">
							<a href="#"><i class="fa fa-thumbs-up fb_like_logo_sizeing" aria-hidden="true"></i>
							</a>
						</div>

					</div>
				</div>

			</div>
		</div>
		<!--search section-->
		<div id="search_froun" class="search_froun_ground">
			<div class="custom-container">
				<?php get_search_form(); ?>
			</div>
		</div>
		<!---Rearch End-->

		<div id="menuground" class="dext_menu_ground">
			<div class="mobile_like_user_part">
				<li>
					<a href="#"><i class="fa fa-thumbs-up fb_like_logo_sizeing" aria-hidden="true"></i>
					</a></li>
				<li><a id="mybtn1"><i class="fa fa-user-circle user_profile_logo_sizeing" aria-hidden="true"></i></a></li>
			</div>
			<div class="custom-container nav_for_mobile_cont_vs">
				<div class="header_part2_level1_ground">
					<?php wp_list_cats('sort_column=name'); ?>

				</div>
				<div class="pt-2 pb-2">
					<div class="footer_part2_level1_ground_h">
						<?php echo $prothom_alo['footr_contact_help'] ?>
					</div>
					<?php echo $prothom_alo['header_Privacy_Terms'] ?>
				</div>


			</div>
		</div>
		<!---Nav Bar END---->
		</br></br></br>
		<section class="Ads_ground1">
			<div class="container">
				<?php echo $prothom_alo['home_ads1'] ?>
			</div>
		</section>

		<!---Ads END---->
		<div class="custom-container">
			<div id="modal">
				<div class="smsground1">
					<div class="transparent1"></div>
					<div class="smsground2">
						<a href="<?php home_ento(); ?>"><img src="<?php echo $prothom_alo['logo_upload']['url'] ?>" class="logo_sizing" alt="logo" /></a>
						<?php
						if (is_user_logged_in()) {
							$current_user = wp_get_current_user();
							echo '<div class="user_gou">Hi, ' . $current_user->display_name . ' </div>';
						} else {
							echo '<div class="user_gou"><li><a href="/wp-login.php" title="Login">Login</a></li><li><a href="/wp-login.php?action=register" title="Signup">Signup</a> </li></div>';
						} ?>

					</div>

				</div>
			</div>
		</div>
