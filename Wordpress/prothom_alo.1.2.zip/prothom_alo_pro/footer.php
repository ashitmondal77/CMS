<?php global $prothom_alo; ?>
<section class="footer_part2_ground">
    <div class="custom-container">
        <div class="footer_part2_level1_ground">
            <?php wp_list_cats('sort_column=name'); ?>

        </div>
        </br>
        <div class="help_Policy_ground1">
            <div class="help_Policy_title"><?php echo $prothom_alo['contact_help_title'] ?></div>
            <div class="footer_part2_level1_ground2">
                <?php echo $prothom_alo['footr_contact_help'] ?>
            </div>
            <p2>
                <?php echo $prothom_alo['footer_nav2'] ?>
            </p2>
        </div>
    </div>
    <div class="help_Policy_ground2">
        <div class="custom-container">
            <p3>
                <?php echo $prothom_alo['footer_nav3'] ?>
            </p3>
        </div>


    </div>

    <a href="#" class="scroll_To_Top"><i class="fas fa-arrow-up"></i></a>
    <?php wp_footer(); ?>

    </body>

    </html>