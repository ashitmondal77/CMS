<?php get_header(); ?>

<h2>Not Found</h2>

<?php get_footer(); ?>        