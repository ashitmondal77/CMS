<?php global $prothom_alo; ?>
<?php get_header(); ?>

<section class="single_page_ground_part1">
	<div class="custom-container">
		<div class="Breadcrumbs_ground">
			<a href="<?php home_ento(); ?>"><i class="fa fa-home"></i></a> › <a><?php single_cat_title(); ?></a>
		</div>
		</br>
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">

			</div>
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<a href="<?php the_permalink(); ?>">
							<ul class="list-unstyled all_post_cart_gropund">
								<li class="media">
									<?php if (has_post_thumbnail()) {
										the_post_thumbnail('small-thumbnail');
									} else {
										echo '<img width="100%" height="100%"src="' . get_bloginfo('template_url') . '/image/Pro_logo.jpg"  alt="ashit mondal" />';
									} ?>
									<div class="media-body">
										<h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
										<p><?php the_excerpt_max_charlength(140); ?></p>
									</div>
								</li>

							</ul>
						</a>

					<?php endwhile; ?>
					<div class="archive_older_privew_ground1">
						<div class="archive_older_post1"><?php previous_posts_link('পেছনে'); ?></div>
						<div class="archive_older_post1"><?php next_posts_link('আরও'); ?></div>
					</div>

					<?php else : ?>
				<?php endif; ?>

			</div>
			<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">

				<div class="tab_ground">
					<div class="tablinks" onclick="openCity(event, 'London')">বিভাগ</div>
					<div class="tablinks" onclick="openCity(event, 'Paris')">আলোচিত</div>
					<div class="tablinks" onclick="openCity(event, 'Tokyo')">ছবি</div>



					<div id="London" class="tabcontent tab_cat_ground">
						<?php wp_list_cats('sort_column=name'); ?>
					</div>



					<div id="Paris" class="tabcontent tabcontent_hide">
						<?php $prothom = new WP_Query('category_name=' . get_cat_name($prothom_alo['atlast_Categories']) . '&posts_per_page=32'); ?>
						<?php if ($prothom->have_posts()) : while ($prothom->have_posts()) : $prothom->the_post(); ?>
								<div class="tab_title_ground">
									<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?> </a></h2>
								</div>
							<?php endwhile; ?>
							<div class="post_ground_title1">
								<?php $ashitiu = $prothom_alo['atlast_Categories']; ?>
								<?php $category_link = get_category_link($ashitiu); ?>
								<!-- Print a link to this category -->
								<a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
							</div>
						<?php else : ?>
						<?php endif; ?>
					</div>





					<div id="Tokyo" class="tabcontent tabcontent_hide">
						<?php $prothom = new WP_Query('category_name=' . get_cat_name($prothom_alo['atlast_Categories']) . '&posts_per_page=32'); ?>
						<?php if ($prothom->have_posts()) : while ($prothom->have_posts()) : $prothom->the_post(); ?>
								<div class="tab_img_ground">
									<a href="<?php the_permalink(); ?>">
										<?php if (has_post_thumbnail()) {
											the_post_thumbnail('thumbnail');
										} else {
											echo '<img width="100" height="100"src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
										} ?>
									</a>
								</div>
							<?php endwhile; ?>
							<div class="post_ground_title1">
								<?php $ashitiu = $prothom_alo['atlast_Categories']; ?>
								<?php $category_link = get_category_link($ashitiu); ?>
								<!-- Print a link to this category -->
								<a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
							</div>
						<?php else : ?>
						<?php endif; ?>
					</div>
				</div>
				<?php get_sidebar(); ?>

			</div>

		</div>

	</div>
</section>






<?php get_footer(); ?>