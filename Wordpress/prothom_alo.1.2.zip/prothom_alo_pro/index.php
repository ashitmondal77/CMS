<?php get_header(); ?>
<?php global $prothom_alo; ?>
<div class="custom-container">
    <div class="Bangla_date_ground">
        <?php echo do_shortcode('[english_date]'); ?>, <?php echo do_shortcode('[bangla_date]'); ?>, <?php echo do_shortcode('[bangla_day]'); ?>, <?php echo do_shortcode('[bangla_time]'); ?>
    </div>
</div>
<div class="dex_custom_container">
    <section class="latest_update_move">
        <div class="latest_update_animation">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                    <img src="<?php echo $prothom_alo['Animation_banner1']['url'] ?>" class="marquee_banner1" />
                </div>
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                    <marquee class="marquee_title_sizeing" behavior="scroll" direction="left" scrollamount="7">
                        <?php $foodpost = new WP_Query('category_name=' . get_cat_name($prothom_alo['marquee_Categories']) . '&posts_per_page=3'); ?>
                        <?php if ($foodpost->have_posts()) : while ($foodpost->have_posts()) : $foodpost->the_post(); ?>
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <?php endwhile;
                        else : ?>
                        <?php endif; ?>
                    </marquee>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 mobile_animation_banner_hide">
                    <img src="<?php echo $prothom_alo['Animation_banner2']['url'] ?>" class="marquee_banner2" />
                </div>
            </div>

        </div>
    </section>
</div>

<!----latest_update_animation END---->

<section class="all_post_ground">
    <div class="custom-container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5 all_post_part2">
                <?php $prothom = new WP_Query('posts_per_page=1'); ?>
                <?php if ($prothom->have_posts()) : while ($prothom->have_posts()) : $prothom->the_post(); ?>
                        <a href="<?php the_permalink(); ?>">
                            <div class="all_post_bg_thumnail_ground">
                                <?php if (has_post_thumbnail()) {
                                    the_post_thumbnail('small-thumbnail');
                                } else {
                                    echo '<img width="100" height="100" 
                                    src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                } ?>

                                <div class="all_post_bg_thumnail-hover_ground"></div>
                                <div class="all_post_bg_thumnail-title_ground">
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?> </a></h2>
                                </div>

                            </div>

                        </a>
                    <?php endwhile;
                else : ?>
                <?php endif; ?>
            </div>
            <!--part1--->
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 all_post_part2">
                <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 4, 'ignore_sticky_posts' => 0,));
                if (have_posts()) : while (have_posts()) : the_post(); ?>

                        <a href="<?php the_permalink(); ?>">
                            <ul class="list-unstyled all_post_cart_gropund">
                                <li class="media">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('small-thumbnail');
                                    } else {
                                        echo '<img width="100" height="100" 
                                        src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                    } ?>
                                    <div class="media-body">
                                        <h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
                                    </div>
                                </li>

                            </ul>
                        </a>
                    <?php endwhile;
                else : ?>
                <?php endif; ?>

            </div>
            <!--part2--->
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 all_post_part2">
                <?php echo $prothom_alo['home_ads2'] ?>
            </div>
        </div>


        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6  all_post_part2">
                        <div class="post_ground_title1">এক ঝলক</div>
                        <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 8, 'ignore_sticky_posts' => 3,));
                        if (have_posts()) : while (have_posts()) : the_post(); ?>

                                <a href="<?php the_permalink(); ?>">
                                    <ul class="list-unstyled all_post_cart_gropund3">
                                        <li class="media">
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail('small-thumbnail');
                                            } else {
                                                echo '<img width="100" height="100" 
                                                src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                            } ?>
                                            <div class="media-body">
                                                <h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
                                            </div>
                                        </li>

                                    </ul>
                                </a>
                            <?php endwhile; ?>
                            <div class="post_ground_title1">
                                <li>আরো</li>
                                <li><?php the_category('') ?></li>
                                <li> সম্পর্কে</li>
                            </div>
                            <?php else : ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6  all_post_part2">
                        <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 4, 'ignore_sticky_posts' => 1,));
                        if (have_posts()) : while (have_posts()) : the_post(); ?>
                                <a href="<?php the_permalink(); ?>">
                                    <ul class="list-unstyled all_post_cart_gropund2">
                                        <li class="media m_bglt">
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail('small-thumbnail');
                                            } else {
                                                echo '<img width="100" height="100" 
                                                src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                            } ?>
                                            <div class="media-body">
                                                <h2 class="carto  mt-1 ml-2 mr-1"><?php the_title(); ?></h2>
                                            </div>
                                        </li>

                                    </ul>
                                </a>
                            <?php endwhile;
                        else : ?>
                        <?php endif; ?>

                    </div>
                </div>
                <!--sub part end--->
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 all_post_part2">
                <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 10, 'ignore_sticky_posts' => 3,));
                if (have_posts()) : while (have_posts()) : the_post(); ?>

                        <a href="<?php the_permalink(); ?>">
                            <ul class="list-unstyled all_post_cart_gropund">
                                <li class="media">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('small-thumbnail');
                                    } else {
                                        echo '<img width="100" height="100" 
                                        src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                    } ?>
                                    <div class="media-body">
                                        <h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
                                    </div>
                                </li>

                            </ul>
                        </a>
                    <?php endwhile;
                else : ?>
                <?php endif; ?>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 all_post_part2">
                <?php echo $prothom_alo['home_ads3'] ?>
            </div>

        </div>
    </div>
</section>
<!---END ALL POST--->

<section class="Ads_ground1">
    <div class="container">
        <img src="https://tpc.googlesyndication.com/simgad/12932806943200048507" style="width:100%; height:100%;" />
    </div>
</section>
<!---Ads END---->









<section class="Cat_ground_all">
    <div class="custom-container">

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['atlast_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="tab_ground">
                    <div class="tablinks" onclick="openCity(event, 'London')">বিভাগ</div>
                    <div class="tablinks" onclick="openCity(event, 'Paris')">আলোচিত</div>
                    <div class="tablinks" onclick="openCity(event, 'Tokyo')">ছবি</div>



                    <div id="London" class="tabcontent tab_cat_ground">
                        <?php wp_list_cats('sort_column=name'); ?>
                    </div>



                    <div id="Paris" class="tabcontent tabcontent_hide">
                        <?php $prothom = new WP_Query('category_name=' . get_cat_name($prothom_alo['atlast_Categories']) . '&posts_per_page=32'); ?>
                        <?php if ($prothom->have_posts()) : while ($prothom->have_posts()) : $prothom->the_post(); ?>
                                <div class="tab_title_ground">
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?> </a></h2>
                                </div>
                            <?php endwhile; ?>
                            <div class="post_ground_title1">
                                <?php $ashitiu = $prothom_alo['atlast_Categories']; ?>
                                <?php $category_link = get_category_link($ashitiu); ?>
                                <!-- Print a link to this category -->
                                <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                            </div>
                        <?php else : ?>
                        <?php endif; ?>
                    </div>





                    <div id="Tokyo" class="tabcontent tabcontent_hide">
                        <?php $prothom = new WP_Query('category_name=' . get_cat_name($prothom_alo['atlast_Categories']) . '&posts_per_page=32'); ?>
                        <?php if ($prothom->have_posts()) : while ($prothom->have_posts()) : $prothom->the_post(); ?>
                                <div class="tab_img_ground">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php if (has_post_thumbnail()) {
                                            the_post_thumbnail('thumbnail');
                                        } else {
                                            echo '<img width="100" height="100"src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                        } ?>
                                    </a>
                                </div>
                            <?php endwhile; ?>
                            <div class="post_ground_title1">
                                <?php $ashitiu = $prothom_alo['atlast_Categories']; ?>
                                <?php $category_link = get_category_link($ashitiu); ?>
                                <!-- Print a link to this category -->
                                <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                            </div>
                        <?php else : ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>


            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['bangladesh_name_Categories'] ?></title1>
                </div>
                <!---title End--->

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 all_post_part2">
                        <?php $bangladesh = new WP_Query('category_name=' . get_cat_name($prothom_alo['bangladesh_Categories']) . '&posts_per_page=4'); ?>
                        <?php if ($bangladesh->have_posts()) : while ($bangladesh->have_posts()) : $bangladesh->the_post(); ?>

                                <a href="<?php the_permalink(); ?>">
                                    <ul class="list-unstyled all_post_cart_gropund">
                                        <li class="media">
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail('small-thumbnail');
                                            } else {
                                                echo '<img width="100" height="100" 
                                                src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                            } ?>
                                            <div class="media-body">
                                                <h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
                                            </div>
                                        </li>

                                    </ul>
                                </a>
                            <?php endwhile;
                        else : ?>
                        <?php endif; ?>
                    </div>
                    <!---part--->
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 all_post_part2">
                        <?php $ashit = $prothom_alo['bangladesh_Categories']; ?>
                        <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 4, 'cat' => $ashit, 'ignore_sticky_posts' => 3,));
                        if (have_posts()) : while (have_posts()) : the_post(); ?>
                                <a href="<?php the_permalink(); ?>">
                                    <ul class="list-unstyled all_post_cart_gropund">
                                        <li class="media">
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail('small-thumbnail');
                                            } else {
                                                echo '<img width="100" height="100" 
                                                src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                            } ?>
                                            <div class="media-body">
                                                <h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
                                            </div>
                                        </li>

                                    </ul>
                                </a>
                            <?php endwhile; ?>
                            <div class="post_ground_title1">
                                <?php $ashitiu = $prothom_alo['atlast_Categories']; ?>
                                <?php $category_link = get_category_link($ashitiu); ?>
                                <!-- Print a link to this category -->
                                <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                            </div>
                        <?php else : ?>
                        <?php endif; ?>
                    </div>
                </div>
                <!----Row End--->
            </div>
        </div>
    </div>
</section>






<section class="play_all_ground">
    <div class="custom-container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['play_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="row play_move_place">
                    <?php $ashit = $prothom_alo['play_Categories']; ?>
                    <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 6, 'cat' => $ashit, 'ignore_sticky_posts' => 1,));
                    if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 play_card_inline">
                                <a href="<?php the_permalink(); ?>">
                                    <ul class="list-unstyled all_post_cart_gropund2">
                                        <li class="media m_bglt1">
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail('small-thumbnail');
                                            } else {
                                                echo '<img width="100" height="100" 
                                                src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                            } ?>
                                            <div class="media-body">
                                                <h2 class="carto  mt-1 ml-2 mr-1"><?php the_title(); ?></h2>
                                                <p><?php the_excerpt_max_charlength(90); ?></p>
                                            </div>
                                        </li>

                                    </ul>
                                </a>
                            </div>
                        <?php endwhile; ?>
                        <div class="post_ground_title2_ground">
                            <div class="post_ground_title2">
                                <?php $ashitiu = $prothom_alo['Feedback_Categories']; ?>
                                <?php $category_link = get_category_link($ashitiu); ?>
                                <!-- Print a link to this category -->
                                <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                            </div>
                        </div>
                    <?php else : ?>
                    <?php endif; ?>

                </div>

            </div>
            <!---part--->
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">ADvaterices
                <?php echo $prothom_alo['home_ads4'] ?>
            </div>
        </div>

    </div>
</section>





<section class="apu_ground">
    <div class="custom-container">
        <!---title--->
        <div class="cat_title_ground">
            <div class="cat_left_border"></div>
            <title1><?php echo $prothom_alo['Entertainment_name_Categories'] ?></title1>
        </div>
        <!---title End--->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5 all_post_part3">
                <?php $prothom = new WP_Query('category_name=' . get_cat_name($prothom_alo['Entertainment_Categories']) . '&posts_per_page=1'); ?>
                <?php if ($prothom->have_posts()) : while ($prothom->have_posts()) : $prothom->the_post(); ?>
                        <a href="<?php the_permalink(); ?>">
                            <div class="all_post_bg_thumnail_ground">
                                <?php if (has_post_thumbnail()) {
                                    the_post_thumbnail('small-thumbnail');
                                } else {
                                    echo '<img width="100" height="100" 
                                    src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                } ?>

                                <div class="all_post_bg_thumnail-hover_ground"></div>
                                <div class="all_post_bg_thumnail-title_ground">
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?> </a></h2>
                                </div>

                            </div>

                        </a>
                    <?php endwhile;
                else : ?>
                <?php endif; ?>
            </div>
            <!--part1--->
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 all_post_part2">
                <?php $ashit = $prothom_alo['Entertainment_Categories']; ?>
                <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 4, 'cat' => $ashit, 'ignore_sticky_posts' => 0,));
                if (have_posts()) : while (have_posts()) : the_post(); ?>

                        <a href="<?php the_permalink(); ?>">
                            <ul class="list-unstyled all_post_cart_gropund">
                                <li class="media">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('small-thumbnail');
                                    } else {
                                        echo '<img width="100" height="100" 
                                        src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                    } ?>
                                    <div class="media-body">
                                        <h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
                                    </div>
                                </li>

                            </ul>
                        </a>
                    <?php endwhile; ?>
                    <div class="post_ground_title2_ground">
                        <div class="post_ground_title2">
                            <?php $ashitiu = $prothom_alo['Feedback_Categories']; ?>
                            <?php $category_link = get_category_link($ashitiu); ?>
                            <!-- Print a link to this category -->
                            <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                        </div>
                    </div>
                <?php else : ?>
                <?php endif; ?>

            </div>
            <!--part2--->
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 all_post_part2">
                <?php echo $prothom_alo['home_ads5'] ?>
            </div>
        </div>
    </div>
</section>
<!---END apu_ground--->


<section class="Opinions_all_ground">
    <div class="custom-container">
        <!---title--->
        <div class="cat_title_ground">
            <div class="cat_left_border"></div>
            <title1><?php echo $prothom_alo['Feedback_name_Categories'] ?></title1>
        </div>
        <!---title End--->
        <div class="row Feedback_ground_move">
            <?php $foodpost = new WP_Query('category_name=' . get_cat_name($prothom_alo['Feedback_Categories']) . '&posts_per_page=4'); ?>
            <?php if ($foodpost->have_posts()) : while ($foodpost->have_posts()) : $foodpost->the_post(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 Opinions_card_inline">
                        <div class="Opinions_card_ground">
                            <h2 class="Opinions_card_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <div class="Opinions_card_dec"><?php the_excerpt_max_charlength(140); ?></div>
                        </div>
                    </div>
                <?php endwhile; ?>
                <div class="post_ground_title2_ground">
                    <div class="post_ground_title2">
                        <?php $ashitiu = $prothom_alo['Feedback_Categories']; ?>
                        <?php $category_link = get_category_link($ashitiu); ?>
                        <!-- Print a link to this category -->
                        <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                    </div>
                </div>
            <?php else : ?>
            <?php endif; ?>

        </div>
    </div>
</section>

<!---END Opinions--->

<section class="Ads_ground1">
    <div class="container">
        <?php echo $prothom_alo['home_ads1'] ?>
    </div>
</section>
<!---Ads END---->



<section class="image_video_all_ground">
    <div class="custom-container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 images_repos">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1 style="color: white;"><?php echo $prothom_alo['photo_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="image_slider_ground">
                    <!--slider code-->
                    <div class="owl-carousel owl-theme">
                        <?php $ashit = new WP_Query('category_name=' . get_cat_name($prothom_alo['photo_Categories']) . '&posts_per_page=3'); ?>
                        <?php if ($ashit->have_posts()) : while ($ashit->have_posts()) : $ashit->the_post(); ?>
                                <div class="image_card_ground">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 image_slider_part1">
                                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                            <p><?php the_excerpt_max_charlength(240); ?></p>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 image_slider_tum">
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail('big-thumbnail');
                                            } else {
                                                echo '<img width="100" height="100" 
                                                src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                            } ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else : ?>
                        <?php endif; ?>

                    </div>

                </div>
                <div class="post_ground_title2_ground pt-md-3 pt-lg-3">
                    <div class="post_ground_title2">
                        <?php $ashitiu = $prothom_alo['Feedback_Categories']; ?>
                        <?php $category_link = get_category_link($ashitiu); ?>
                        <!-- Print a link to this category -->
                        <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                    </div>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                <!---title--->
                <div class="cat_title_ground video_cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1 style="color: white;"><?php echo $prothom_alo['video_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="video_card_ground">
                    <?php $ashit = new WP_Query('category_name=' . get_cat_name($prothom_alo['video_Categories']) . '&posts_per_page=3'); ?>
                    <?php if ($ashit->have_posts()) : while ($ashit->have_posts()) : $ashit->the_post(); ?>
                            <a href="<?php the_permalink(); ?>">
                                <ul class="list-unstyled all_post_cart_gropund4">
                                    <li class="media">
                                        <?php if (has_post_thumbnail()) {
                                            the_post_thumbnail('small-thumbnail');
                                        } else {
                                            echo '<img width="100" height="100" 
                                            src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                        } ?>
                                        <div class="media-body video_title">
                                            <h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
                                        </div>
                                    </li>

                                </ul>
                            </a>
                        <?php endwhile; ?>
                        <div class="post_ground_title2_ground">
                            <div class="post_ground_title2">
                                <?php $ashitiu = $prothom_alo['Feedback_Categories']; ?>
                                <?php $category_link = get_category_link($ashitiu); ?>
                                <!-- Print a link to this category -->
                                <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                            </div>
                        </div>
                    <?php else : ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</section>
<!----End---->

<!---Ashit Update--->

<section class="all_cat_news_ground">
    <div class="custom-container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 mt-2">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['International_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="cat_news_part_tum">
                    <?php $foodpost = new WP_Query('category_name=' . get_cat_name($prothom_alo['International_Categories']) . '&posts_per_page=1'); ?>
                    <?php if ($foodpost->have_posts()) : while ($foodpost->have_posts()) : $foodpost->the_post(); ?>
                            <a href="<?php the_permalink(); ?>">
                                <div class="all_cat_news_card_ground_tum">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('small-thumbnail');
                                    } else {
                                        echo '<img width="100" height="100" 
                                        src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                    } ?>
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <p><?php the_excerpt_max_charlength(130); ?></p>
                                </div>
                            </a>
                        <?php endwhile;
                    else : ?>
                    <?php endif; ?>
                    <!----part---->
                    <?php $ashit_catbl1 = $prothom_alo['International_Categories']; ?>
                    <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 5, 'cat' => $ashit_catbl1, 'ignore_sticky_posts' => 0,));
                    if (have_posts()) : while (have_posts()) : the_post(); ?>

                            <div class="all_cat_news_card_ground_tum">
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                        <?php endwhile; ?>

                        <div class="post_ground_title_tum3">
                            <?php $ashitiu = $prothom_alo['International_Categories']; ?>
                            <?php $category_link = get_category_link($ashitiu); ?>
                            <!-- Print a link to this category -->
                            <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                        </div>
                    <?php else : ?>
                    <?php endif; ?>
                </div>

            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 mt-2">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['Far_away_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="cat_news_part_tum">
                    <?php $foodpost = new WP_Query('category_name=' . get_cat_name($prothom_alo['Far_away_Categories']) . '&posts_per_page=1'); ?>
                    <?php if ($foodpost->have_posts()) : while ($foodpost->have_posts()) : $foodpost->the_post(); ?>
                            <a href="<?php the_permalink(); ?>">
                                <div class="all_cat_news_card_ground_tum">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('small-thumbnail');
                                    } else {
                                        echo '<img width="100" height="100" 
                                        src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                    } ?>
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <p><?php the_excerpt_max_charlength(130); ?></p>
                                </div>
                            </a>
                        <?php endwhile;
                    else : ?>
                    <?php endif; ?>
                    <!----part---->
                    <?php $ashit_catbl1 = $prothom_alo['Far_away_Categories']; ?>
                    <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 5, 'cat' => $ashit_catbl1, 'ignore_sticky_posts' => 0,));
                    if (have_posts()) : while (have_posts()) : the_post(); ?>

                            <div class="all_cat_news_card_ground_tum">
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                        <?php endwhile; ?>

                        <div class="post_ground_title_tum3">
                            <?php $ashitiu = $prothom_alo['Far_away_Categories']; ?>
                            <?php $category_link = get_category_link($ashitiu); ?>
                            <!-- Print a link to this category -->
                            <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                        </div>
                    <?php else : ?>
                    <?php endif; ?>
                </div>

            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 mt-2">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['North_America_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="cat_news_part_tum">
                    <?php $foodpost = new WP_Query('category_name=' . get_cat_name($prothom_alo['North_America_Categories']) . '&posts_per_page=1'); ?>
                    <?php if ($foodpost->have_posts()) : while ($foodpost->have_posts()) : $foodpost->the_post(); ?>
                            <a href="<?php the_permalink(); ?>">
                                <div class="all_cat_news_card_ground_tum">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('small-thumbnail');
                                    } else {
                                        echo '<img width="100" height="100" 
                                        src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                    } ?>
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <p><?php the_excerpt_max_charlength(130); ?></p>
                                </div>
                            </a>
                        <?php endwhile;
                    else : ?>
                    <?php endif; ?>
                    <!----part---->
                    <?php $ashit_catbl1 = $prothom_alo['North_America_Categories']; ?>
                    <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 5, 'cat' => $ashit_catbl1, 'ignore_sticky_posts' => 0,));
                    if (have_posts()) : while (have_posts()) : the_post(); ?>

                            <div class="all_cat_news_card_ground_tum">
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                        <?php endwhile; ?>

                        <div class="post_ground_title_tum3">
                            <?php $ashitiu = $prothom_alo['North_America_Categories']; ?>
                            <?php $category_link = get_category_link($ashitiu); ?>
                            <!-- Print a link to this category -->
                            <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                        </div>
                    <?php else : ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</section>


<section class="play_all_ground">
    <div class="custom-container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['design_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="row play_move_place">
                    <?php $ashit = $prothom_alo['design_Categories']; ?>
                    <?php query_posts(array('orderby' => 'rand', 'posts_per_page' => 6, 'cat' => $ashit, 'ignore_sticky_posts' => 1,));
                    if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 play_card_inline">
                                <a href="<?php the_permalink(); ?>">
                                    <ul class="list-unstyled all_post_cart_gropund2">
                                        <li class="media m_bglt1">
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail('small-thumbnail');
                                            } else {
                                                echo '<img width="100" height="100" 
                                                src="https://1.bp.blogspot.com/-5Qpo20OHDOk/XyTqQhWoeRI/AAAAAAAAA7I/3Qa2IJUhh7ErRTEz0972tCPmBspSQmgLwCLcBGAsYHQ/w288-h286/ppo.jpg" class="ashit" alt="Default image" />';
                                            } ?>
                                            <div class="media-body">
                                                <h2 class="carto  mt-1 ml-2 mr-1"><?php the_title(); ?></h2>
                                                <p><?php the_excerpt_max_charlength(90); ?></p>
                                            </div>
                                        </li>

                                    </ul>
                                </a>
                            </div>
                        <?php endwhile; ?>
                        <div class="post_ground_title2_ground">
                            <div class="post_ground_title2">
                                <?php $ashitiu = $prothom_alo['Feedback_Categories']; ?>
                                <?php $category_link = get_category_link($ashitiu); ?>
                                <!-- Print a link to this category -->
                                <a href="<?php echo esc_url($category_link); ?>" title="Category Name">আরো</a>
                            </div>
                        </div>
                    <?php else : ?>
                    <?php endif; ?>

                </div>

            </div>
            <!---part--->
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">ADvaterices
                <?php echo $prothom_alo['home_ads4'] ?>
            </div>
        </div>

    </div>
</section>



<section class="all_cat_news_ground">
    <div class="custom-container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 mt-2">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['Economy_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="cat_news_part">
                    <?php $ashit = new WP_Query('category_name=' . get_cat_name($prothom_alo['Economy_Categories']) . '&posts_per_page=5'); ?>
                    <?php if ($ashit->have_posts()) : while ($ashit->have_posts()) : $ashit->the_post(); ?>
                            <div class="all_cat_news_card_ground">
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                        <?php endwhile;
                    else : ?>
                    <?php endif; ?>
                </div>

            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 mt-2">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['Living_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="cat_news_part">
                    <?php $ashit = new WP_Query('category_name=' . get_cat_name($prothom_alo['Living_Categories']) . '&posts_per_page=5'); ?>
                    <?php if ($ashit->have_posts()) : while ($ashit->have_posts()) : $ashit->the_post(); ?>
                            <div class="all_cat_news_card_ground">
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                        <?php endwhile;
                    else : ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 mt-2">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['Science_and_technology_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="cat_news_part">
                    <?php $ashit = new WP_Query('category_name=' . get_cat_name($prothom_alo['Science_and_technology_Categories']) . '&posts_per_page=5'); ?>
                    <?php if ($ashit->have_posts()) : while ($ashit->have_posts()) : $ashit->the_post(); ?>
                            <div class="all_cat_news_card_ground">
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                        <?php endwhile;
                    else : ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 mt-2">
                <!---title--->
                <div class="cat_title_ground">
                    <div class="cat_left_border"></div>
                    <title1><?php echo $prothom_alo['Citizen_News_name_Categories'] ?></title1>
                </div>
                <!---title End--->
                <div class="cat_news_part">
                    <?php $ashit = new WP_Query('category_name=' . get_cat_name($prothom_alo['Citizen_News_Categories']) . '&posts_per_page=5'); ?>
                    <?php if ($ashit->have_posts()) : while ($ashit->have_posts()) : $ashit->the_post(); ?>
                            <div class="all_cat_news_card_ground">
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                        <?php endwhile;
                    else : ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<br /><br /><br />




<?php get_footer(); ?>