<?php

/**
 * ReduxFramework Sample Config File
 * For full documentation, please visit: http://docs.reduxframework.com/
 */
if (!class_exists('Redux')) {
    return;
}
// This is your option name where all the Redux data is stored.
$opt_name = "redux_demo";

// This line is only for altering the demo. Can be easily removed.
$opt_name = apply_filters('redux_demo/opt_name', $opt_name);

/*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

$sampleHTML = '';
if (file_exists(dirname(__FILE__) . '/info-html.html')) {
    Redux_Functions::initWpFilesystem();

    global $wp_filesystem;

    $sampleHTML = $wp_filesystem->get_contents(dirname(__FILE__) . '/info-html.html');
}

// Background Patterns Reader
$sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
$sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
$sample_patterns      = array();

if (is_dir($sample_patterns_path)) {

    if ($sample_patterns_dir = opendir($sample_patterns_path)) {
        $sample_patterns = array();

        while (($sample_patterns_file = readdir($sample_patterns_dir)) !== false) {

            if (stristr($sample_patterns_file, '.png') !== false || stristr($sample_patterns_file, '.jpg') !== false) {
                $name              = explode('.', $sample_patterns_file);
                $name              = str_replace('.' . end($name), '', $sample_patterns_file);
                $sample_patterns[] = array(
                    'alt' => $name,
                    'img' => $sample_patterns_url . $sample_patterns_file
                );
            }
        }
    }
}

/**
 * ---> SET ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 * */

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name'             => $opt_name,
    // This is where your data is stored in the database and also becomes your global variable name.
    'display_name'         => $theme->get('Name'),
    // Name that appears at the top of your panel
    'display_version'      => $theme->get('Version'),
    // Version that appears at the top of your panel
    'menu_type'            => 'menu',
    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu'       => true,

    // Ashit: Main Menu Name and Title
    'menu_title'           => __('Prothom alo customize', 'Ashit Builder'),
    'page_title'           => __('Prothom alo customize', 'Ashit Builder'),

    // You will need to generate a Google API key to use this feature.
    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
    'google_api_key'       => false,
    // Set it you want google fonts to update weekly. A google_api_key value is required.
    'google_update_weekly' => false,
    // Must be defined to add google fonts to the typography module
    'async_typography'     => false,
    // Use a asynchronous font on the front end or font string
    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader

    //Ashit: Show the panel pages on the admin bar and icon
    'admin_bar'            => true,
    'admin_bar_icon'       => 'dashicons-portfolio',
    // Choose an icon for the admin bar menu
    'admin_bar_priority'   => 50,
    // Choose an priority for the admin bar menu
    'global_variable'      => 'prothom_alo',
    // Set a different name for your global variable other than the opt_name
    //Ashit: alart Notice
    'dev_mode'             => false,
    // Show the time the page took to load, etc
    'update_notice'        => true,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    // Ashit: Customizer Theme Add
    'customizer'           => true,
    // Enable basic customizer support
    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

    // OPTIONAL -> Give you extra features
    //Ashit: Position Menu. google Search [wordpress Admin Menu position list]
    'page_priority'        => 61,
    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent'          => 'themes.php',
    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions'     => 'manage_options',
    // Permissions needed to access the options panel.

    //Ashit: Main Menu Icon URL.
    'menu_icon'            => '',
    // Specify a custom URL to an icon
    'last_tab'             => '',
    // Force your panel to always open to a specific tab (by id)
    'page_icon'            => 'icon-themes',
    // Icon displayed in the admin panel next to your menu_title

    //Ashit: URL Name Change Dev: mode.
    'page_slug'            => 'prothom_alo',
    // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided.
    //Ashit: Auto Save Settings
    'save_defaults'        => true,
    // On load save the defaults to DB before user clicks save or not
    'default_show'         => false,
    // If true, shows the default value next to each field that is not the default value.
    'default_mark'         => '',
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export'   => true,
    // Shows the Import/Export panel when not used as a field.

    // CAREFUL -> These options are for advanced use only
    'transient_time'       => 60 * MINUTE_IN_SECONDS,
    'output'               => true,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag'           => true,
    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    'database'             => '',
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
    'use_cdn'              => true,
    // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    // HINTS
    'hints'                => array(
        'icon'          => 'el el-question-sign',
        'icon_position' => 'right',
        'icon_color'    => 'lightgray',
        'icon_size'     => 'normal',
        'tip_style'     => array(
            'color'   => 'red',
            'shadow'  => true,
            'rounded' => false,
            'style'   => '',
        ),
        'tip_position'  => array(
            'my' => 'top left',
            'at' => 'bottom right',
        ),
        'tip_effect'    => array(
            'show' => array(
                'effect'   => 'slide',
                'duration' => '500',
                'event'    => 'mouseover',
            ),
            'hide' => array(
                'effect'   => 'slide',
                'duration' => '500',
                'event'    => 'click mouseleave',
            ),
        ),
    )
);

// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
$args['admin_bar_links'][] = array(
    'id'    => 'redux-docs',
    'href'  => 'https://www.ashitbd.xyz/',
    'title' => __('Documentation', 'redux-framework-demo'),
);

$args['admin_bar_links'][] = array(
    //'id'    => 'redux-support',
    'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
    'title' => __('Support', 'redux-framework-demo'),
);

$args['admin_bar_links'][] = array(
    'id'    => 'redux-extensions',
    'href'  => 'https://www.ashitbd.xyz/',
    'title' => __('Extensions', 'redux-framework-demo'),
);

// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
$args['share_icons'][] = array(
    'url'   => 'https://www.ashitbd.xyz/',
    'title' => 'Visit us on GitHub',
    'icon'  => 'el el-github'
    //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
);
$args['share_icons'][] = array(
    'url'   => 'https://www.facebook.com/ashitmondal.550',
    'title' => 'Like us on Facebook',
    'icon'  => 'el el-facebook'
);
$args['share_icons'][] = array(
    'url'   => 'https://twitter.com/ashitmondal550',
    'title' => 'Follow us on Twitter',
    'icon'  => 'el el-twitter'
);
$args['share_icons'][] = array(
    'url'   => 'https://www.linkedin.com/in/ashit-mondal-7385b3158/',
    'title' => 'Find us on LinkedIn',
    'icon'  => 'el el-linkedin'
);

// Panel Intro text -> before the form
if (!isset($args['global_variable']) || $args['global_variable'] !== false) {
    if (!empty($args['global_variable'])) {
        $v = $args['global_variable'];
    } else {
        $v = str_replace('-', '_', $args['opt_name']);
    }
    $args['intro_text'] = sprintf(__('Prothom Alo Customizion.'), $v);
} else {
    $args['intro_text'] = __('<p>Theme Full Cortrol.</p>', 'redux-framework-demo');
}

// Add content after the form.
$args['footer_text'] = __('<p>Theme Full Cortrol.</p>', 'redux-framework-demo');

Redux::setArgs($opt_name, $args);


$tabs = array(
    array(
        'id'      => 'redux-help-tab-1',
        'title'   => __('Theme Information 1', 'redux-framework-demo'),
        'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo')
    ),
    array(
        'id'      => 'redux-help-tab-2',
        'title'   => __('Theme Information 2', 'redux-framework-demo'),
        'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo')
    )
);
Redux::setHelpTab($opt_name, $tabs);

// Set the help sidebar
$content = __('<p>This is the sidebar content, HTML is allowed.</p>', 'redux-framework-demo');
Redux::setHelpSidebar($opt_name, $content);

/*---ASHIT ADD option-----*/

/*==========================================================
//Categories Part
==============================================================*/

Redux::setSection($opt_name, array(
    'title'            => __('Home Categories', 'ashitbd.xyz'),
    'id'               => 'Categories_ground',
    'desc'             => __('About for Categories', 'ashitbd.xyz'),
    'icon'             => 'el el-filter'
));
//marquee post-part-1
Redux::setSection($opt_name, array(
    'title'            => __('Top Animation Update', 'ashitbd.xyz'),
    'id'               => 'Categories_part1',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(

        array(
            'title'    => __('marquee Post', 'ashit'),
            'id'       => 'marquee_Categories',
            'subtitle' => __('change for Animation Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),
        array(
            'id'       => 'Animation_banner1',
            'type'     => 'media',
            'title'    => __('Animation banner - width: 244px; AND Height: 50px;', 'ashitbd.xyz'),
            'subtitle' => __('This must be a URL.', 'ashitbd.xyz'),
            'compiler' => 'true',
            'default'  => array( 'url' => 'https://1.bp.blogspot.com/-nSspUl9h9Qg/XyEzWTqkWQI/AAAAAAAAA5o/r5XJGcS2T8oxLV9aI9phQsAMPXSBmTP7QCLcBGAsYHQ/s244/nony2.png' ),
            'preview'  => true,
        ),
        array(
            'id'       => 'Animation_banner2',
            'type'     => 'media',
            'title'    => __('Animation banner - width: 200px; AND Height: 52px;', 'ashitbd.xyz'),
            'subtitle' => __('This must be a URL.', 'ashitbd.xyz'),
            'compiler' => 'true',
            'default'  => array( 'url' => 'https://1.bp.blogspot.com/-I0s_TYYkdOE/XyEzMUbcl3I/AAAAAAAAA5k/U2f2L2gAXEw0ZkoWgyqcVK4WDQ4VAlOLwCLcBGAsYHQ/s200/nony1.png' ),
            'preview'  => true,
        ),


    )
));

//সব খবর-part2
Redux::setSection($opt_name, array(
    'title'            => __('সব খবর', 'ashitbd.xyz'),
    'id'               => 'Categories_part2',
    'subsection'       => true,
    'desc'             => __('NO Categories Change', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',

));

//সবচেয়ে-বাংলাদেশ-part3
Redux::setSection($opt_name, array(
    'title'            => __('সবচেয়ে,বাংলাদেশ', 'ashitbd.xyz'),
    'id'               => 'Categories_part3',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(
        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'atlast_name_Categories',
            'type'     => 'text',
            'default'  => 'সবচেয়ে',

        ),

        array(
            'title'    => __('সবচেয়ে', 'ashit'),
            'id'       => 'atlast_Categories',
            'subtitle' => __('change for Atlast news Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',
        ),

        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'bangladesh_name_Categories',
            'type'     => 'text',
            'default'  => 'বাংলাদেশ',

        ),
        array(
            'title'    => __('বাংলাদেশ', 'ashit'),
            'id'       => 'bangladesh_Categories',
            'subtitle' => __('change for Bangladesh news Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),

    )
));
//খেলা-part4
Redux::setSection($opt_name, array(
    'title'            => __('খেলা', 'ashitbd.xyz'),
    'id'               => 'Categories_part4',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(

        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'play_name_Categories',
            'type'     => 'text',
            'default'  => 'খেলা',
        ),
        array(
            'title'    => __('খেলা', 'ashit'),
            'id'       => 'play_Categories',
            'subtitle' => __(' change for play Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),

    )
));

//বিনোদন-part-5
Redux::setSection($opt_name, array(
    'title'            => __('বিনোদন', 'ashitbd.xyz'),
    'id'               => 'Categories_part5',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(

        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'Entertainment_name_Categories',
            'type'     => 'text',
            'default'  => 'বিনোদন',

        ),
        array(
            'title'    => __('বিনোদন', 'ashit'),
            'id'       => 'Entertainment_Categories',
            'subtitle' => __(' change for Entertainment Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),

    )
));

//মতামত-part-6
Redux::setSection($opt_name, array(
    'title'            => __('মতামত', 'ashitbd.xyz'),
    'id'               => 'Categories_part6',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(

        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'Feedback_name_Categories',
            'type'     => 'text',
            'default'  => 'মতামত',
        ),
        array(
            'title'    => __('মতামত', 'ashit'),
            'id'       => 'Feedback_Categories',
            'subtitle' => __(' change for Feedback Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',
        ),

    )
));

//ছবি,ভিডিও-part-7
Redux::setSection($opt_name, array(
    'title'            => __('ছবি,ভিডিও', 'ashitbd.xyz'),
    'id'               => 'Categories_part7',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(

        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'photo_name_Categories',
            'type'     => 'text',
            'default'  => 'ছবি',
        ),
        array(
            'title'    => __('ছবি', 'ashit'),
            'id'       => 'photo_Categories',
            'subtitle' => __(' change for photo Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),
        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'video_name_Categories',
            'type'     => 'text',
            'default'  => 'ভিডিও',
        ),
        array(
            'title'    => __('ভিডিও', 'ashit'),
            'id'       => 'video_Categories',
            'subtitle' => __(' change for video Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),

    )
));


//আন্তর্জাতিক ,দূর পরবাস,উত্তর আমেরিকা-part-8
Redux::setSection($opt_name, array(
    'title'            => __('আ ,দূ ,উ', 'ashitbd.xyz'),
    'id'               => 'Categories_part8',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(

        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'International_name_Categories',
            'type'     => 'text',
            'default'  => 'আন্তর্জাতিক',
        ),
        array(
            'title'    => __('আন্তর্জাতিক', 'ashit'),
            'id'       => 'International_Categories',
            'subtitle' => __(' change for International Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),
        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'Far_away_name_Categories',
            'type'     => 'text',
            'default'  => 'দূর পরবাস',
        ),
        array(
            'title'    => __('দূর পরবাস', 'ashit'),
            'id'       => 'Far_away_Categories',
            'subtitle' => __(' change for Far_away Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),
        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'North_America_name_Categories',
            'type'     => 'text',
            'default'  => 'উত্তর আমেরিকা',
        ),
        array(
            'title'    => __('উত্তর আমেরিকা', 'ashit'),
            'id'       => 'North_America_Categories',
            'subtitle' => __(' change for North_America Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),

    )
));

//নকশা-part-9
Redux::setSection($opt_name, array(
    'title'            => __('নকশা', 'ashitbd.xyz'),
    'id'               => 'Categories_part9',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(

        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'design_name_Categories',
            'type'     => 'text',
            'default'  => 'নকশা',
        ),
        array(
            'title'    => __('নকশা', 'ashit'),
            'id'       => 'design_Categories',
            'subtitle' => __(' change for photo Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),


    )
));


//অর্থনীতি,জীবনযাপন....-part-10
Redux::setSection($opt_name, array(
    'title'            => __('অ,জী,বি,না', 'ashitbd.xyz'),
    'id'               => 'Categories_part10',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file-new',
    'fields'           => array(

        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'Economy_name_Categories',
            'type'     => 'text',
            'default'  => 'অর্থনীতি',
        ),
        array(
            'title'    => __('অর্থনীতি', 'ashit'),
            'id'       => 'Economy_Categories',
            'subtitle' => __(' change for Economy Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),
        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'Living_name_Categories',
            'type'     => 'text',
            'default'  => 'জীবনযাপন',
        ),
        array(
            'title'    => __('জীবনযাপন', 'ashit'),
            'id'       => 'Living_Categories',
            'subtitle' => __(' change for Living Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),
        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'Science_and_technology_name_Categories',
            'type'     => 'text',
            'default'  => 'বিজ্ঞান ও প্রযুক্তি',
        ),
        array(
            'title'    => __('বিজ্ঞান ও প্রযুক্তি', 'ashit'),
            'id'       => 'Science_and_technology_Categories',
            'subtitle' => __(' change for Science and technology Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),
        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'Citizen_News_name_Categories',
            'type'     => 'text',
            'default'  => 'নাগরিক সংবাদ',
        ),
        array(
            'title'    => __('নাগরিক সংবাদ', 'ashit'),
            'id'       => 'Citizen_News_Categories',
            'subtitle' => __(' change for Citizen News Categories.', 'ashit'),
            'type'     => 'select',
            'data'     => 'categories',


        ),

    )
));
/*==========================================================
//Home page Ads
==============================================================*/

Redux::setSection($opt_name, array(
    'title'            => __('Home Ads', 'ashitbd.xyz'),
    'id'               => 'home_ads',
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-list'
));

Redux::setSection($opt_name, array(
    'title'            => __('Banner Or Ads', 'ashitbd.xyz'),
    'id'               => 'home_yt_ads',
    'subsection'       => true,
    'desc'             => __('You Can Use HTML Code OR Can you Use Google ads Js code', 'ashitbd.xyz'),
    'icon'             => 'el el-bulb',
    'fields'     => array(
        array(
            'id'           => 'home_ads1',
            'type'         => 'textarea',
            'title'        => __('Custom HTML Allowed', 'prothom alo'),
            'validate'     => 'html_custom',
            'default'      => '<img src="https://tpc.googlesyndication.com/simgad/8461930757717145768" style="width:100%; height:100%;"/>',
        ),
        array(
            'id'           => 'home_ads2',
            'type'         => 'textarea',
            'title'        => __('Custom HTML Allowed', 'prothom alo'),
            'validate'     => 'html_custom',
            'default'      => '<img src="https://tpc.googlesyndication.com/simgad/13017007723978827825" width="100%" height="300px" />',
        ),
        array(
            'id'           => 'home_ads3',
            'type'         => 'textarea',
            'title'        => __('Custom HTML Allowed', 'prothom alo'),
            'validate'     => 'html_custom',
            'default'      => '
            <img src="https://service.prothomalo.com/palo/ads/gp-dakcheamardesh-480X150.gif" width="100%" height="120px" />
                <br /><br />
                <img src="https://tpc.googlesyndication.com/simgad/7592078496486028223" width="100%" height="280px" />
                <br /><br />
                <img src="https://paloimages.prothom-alo.com/contents/cache/images/540X210X1/uploads/media/2020/05/27/05c076570fa21358cba622d19a5eb21b-5ecdf9c06f11b.png" width="100%" height="190px" />
                <br /><br />
                <img src=" https://wpleaders.com/wp-content/uploads/2018/03/Thrive-Architect.gif" width="100%" height="190px" />
            ',
        ),
        array(
            'id'           => 'home_ads4',
            'type'         => 'textarea',
            'title'        => __('Custom HTML Allowed', 'prothom alo'),
            'validate'     => 'html_custom',
            'default'      => '
            <img src="https://service.prothomalo.com/palo/ads/gp-dakcheamardesh-480X150.gif" width="100%" height="120px" />
                <br /><br />
                <img src="https://tpc.googlesyndication.com/simgad/7592078496486028223" width="100%" height="280px" />
                <br /><br />
                <img src="https://paloimages.prothom-alo.com/contents/cache/images/540X210X1/uploads/media/2020/05/27/05c076570fa21358cba622d19a5eb21b-5ecdf9c06f11b.png" width="100%" height="190px" />
            ',
        ),
        array(
            'id'           => 'home_ads5',
            'type'         => 'textarea',
            'title'        => __('Custom HTML Allowed', 'prothom alo'),
            'validate'     => 'html_custom',
            'default'      => '
            <img src="https://tpc.googlesyndication.com/simgad/13017007723978827825" width="100%" height="300px" />
            ',
        ),

    )
));

/*==========================================================
//SideBar page Ads
==============================================================*/

Redux::setSection($opt_name, array(
    'title'            => __('SideBar Ads', 'ashitbd.xyz'),
    'id'               => 'sidebar_ads',
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-list'
));

Redux::setSection($opt_name, array(
    'title'            => __('Banner Or Ads', 'ashitbd.xyz'),
    'id'               => 'sidebar_yt_ads',
    'subsection'       => true,
    'desc'             => __('You Can Use HTML Code OR Can you Use Google ads Js code', 'ashitbd.xyz'),
    'icon'             => 'el el-bulb',
    'fields'     => array(
        array(
            'id'           => 'sidebar_ads1',
            'type'         => 'textarea',
            'title'        => __('Custom HTML Allowed', 'prothom alo'),
            'validate'     => 'html_custom',
            'default'      => '
            <img src="https://tpc.googlesyndication.com/simgad/13017007723978827825" width="100%" height="300px" />
            ',
        ),


    )
));

/*==========================================================
//Header
==============================================================*/

Redux::setSection($opt_name, array(
    'title'            => __('header', 'ashitbd.xyz'),
    'id'               => 'header_ground',
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file'
));
Redux::setSection($opt_name, array(
    'title'            => __('logo', 'ashitbd.xyz'),
    'id'               => 'gallery',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-picture',
    'fields'           => array(

        array(
            'id'       => 'logo_upload',
            'type'     => 'media',
            'title'    => __('Brand Logo - Upload', 'ashitbd.xyz'),
            'subtitle' => __('This must be a URL.', 'ashitbd.xyz'),
            'compiler' => 'true',
            'default'  => array( 'url' => 'https://1.bp.blogspot.com/-_5IDZXpfdak/XyE0akVdB2I/AAAAAAAAA54/aqHvjczxHOADJASnwSwa8XbEzfZNqsTYwCLcBGAsYHQ/s195/Prothom-Alo%2B%25281%2529.png' ),
            'preview'  => true,
        ),
        array(
            'id'       => 'favicon_upload',
            'type'     => 'media',
            'title'    => __('favicon Icon - Upload', 'ashitbd.xyz'),
            'subtitle' => __('This must be a URL.', 'ashitbd.xyz'),
            'compiler' => 'true',
            'default'  => array('url' => get_stylesheet_directory_uri() . '/image/favicon.png'),
            'preview'  => true,


        ),
    )
));
//Nav
Redux::setSection($opt_name, array(
    'title'            => __('Navigation menu', 'ashitbd.xyz'),
    'id'               => 'header_navigation',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-align-center',
    'fields'           => array(

        array(
            'id'           => 'header_nav1',
            'type'         => 'textarea',
            'title'        => __('maximum Menu: 8 ', 'prothom alo'),
            'subtitle' => __('HTML', 'ashitbd.xyz'),
            'validate'     => 'html_custom',
            'default'      => '
<li><a href="#">বাংলাদেশ</a></li>
<li><a href="#">আন্তর্জাতিক</a></li>
<li><a href="#">অর্থনীতি</a></li>
<li><a href="#">মতামত</a></li>
<li><a href="#">খেলা</a></li>
<li><a href="#">বিনোদন</a></li>
<li><a href="#">উত্তর আমেরিকা</a></li>
<li><a href="#">ভিডিও</a></li>
            ',
        ),
        array(
            'id'           => 'header_Privacy_Terms',
            'type'         => 'textarea',
            'title'        => __('Privacy Policy and Terms of Use', 'prothom alo'),
            'subtitle' => __('HTML', 'ashitbd.xyz'),
            'validate'     => 'html_custom',
            'default'      => '
<a href="https://www.ashitbd.xyz">Privacy Policy</a> | <a href="https://www.ashitbd.xyz">Terms of Use</a>.        
            ',
        ),

    )
));
/*==========================================================
//Footer
==============================================================*/

Redux::setSection($opt_name, array(
    'title'            => __('Footer', 'ashitbd.xyz'),
    'id'               => 'footer_ground',
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-file'
));
Redux::setSection($opt_name, array(
    'title'            => __('সহায়তা এবং যোগাযোগ', 'ashitbd.xyz'),
    'id'               => 'contact_help_ground',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-home',

    'fields'     => array(
        array(
            'title'    => __('Title', 'ashit'),
            'id'       => 'contact_help_title',
            'type'     => 'text',
            'default'  => 'সহায়তা এবং যোগাযোগ',
        ),
        array(
            'id'           => 'footr_contact_help',
            'type'         => 'textarea',
            'title'        => __('All custom Cat: AND Auto Save Manu', 'prothom alo'),
            'subtitle' => __('HTML', 'ashitbd.xyz'),
            'validate'     => 'html_custom',
            'default'      => '
<li><a href="https://www.ashitbd.xyz"><img src="https://paloimages.prothom-alo.com/contents/themes/public/style/images/2221_icon.png" class="opuy" />২২২২১</a></li>

<li><a href="https://www.ashitbd.xyz"><img src="https://paloimages.prothom-alo.com/contents/themes/public/style/images/abcradio_icon.png" class="opuy" />abc রেডিও</a></li>

<li><a href="https://www.ashitbd.xyz"><img src="https://paloimages.prothom-alo.com/contents/themes/public/style/images/trust_icon.png" class="opuy" />ট্রাস্ট</a></li>

<li><a href="https://www.ashitbd.xyz"><img src="https://paloimages.prothom-alo.com/contents/themes/public/style/images/2221_icon.png" class="opuy" />কিশোর আলো</a></li>

<li><a href="https://www.ashitbd.xyz"><img src="https://service.prothomalo.com/palo/logos/prothoma.png" class="opuy" />প্রতিচিন্তা</a></li>
            ',
        
        ),

    )
));


Redux::setSection($opt_name, array(
    'title'            => __('Footer_navigation', 'ashitbd.xyz'),
    'id'               => 'footr_navg',
    'subsection'       => true,
    'desc'             => __('About for option', 'ashitbd.xyz'),
    'icon'             => 'el el-align-center',
    'fields'           => array(
        
        array(
            'id'           => 'footer_nav2',
            'type'         => 'textarea',
            'title'        => __('Privacy Policy and Terms of Use', 'prothom alo'),
            'subtitle' => __('HTML', 'ashitbd.xyz'),
            'validate'     => 'html_custom',
            'default'      => '
Prothom Alo is the highest circulated and most read newspaper in Bangladesh. The online portal of Prothom Alo is the most visited Bangladeshi and Bengali website in the world.
<a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a>.        
            ',
        ),

        array(
            'id'           => 'footer_nav3',
            'type'         => 'textarea',
            'title'        => __('About ', 'prothom alo'),
            'subtitle' => __('HTML', 'ashitbd.xyz'),
            'validate'     => 'html_custom',
            'default'      => '
© স্বত্ব প্রথম আলো ১৯৯৮ - ২০২০</br>
সম্পাদক ও প্রকাশক: মতিউর রহমান</br>
প্রগতি ইনস্যুরেন্স ভবন, ২০-২১ কারওয়ান বাজার, ঢাকা ১২১৫</br>
ফোন: 01939923350, ফ্যাক্স: ৫৫০১২২০০, ৫৫০১২২১১ ইমেইল: ashitmondal77@gmail.com      
            ',
        ),
    )
));














/*---ASHIT END option-----*/



if (!function_exists('compiler_action')) {
    function compiler_action($options, $css, $changed_values)
    {
        echo '<h1>The compiler hook has run!</h1>';
        echo "<pre>";
        print_r($changed_values); // Values that have changed since the last save
        echo "</pre>";
        //print_r($options); //Option values
        //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
    }
}

/**
 * Custom function for the callback validation referenced above
 * */
if (!function_exists('redux_validate_callback_function')) {
    function redux_validate_callback_function($field, $value, $existing_value)
    {
        $error   = false;
        $warning = false;

        //do your validation
        if ($value == 1) {
            $error = true;
            $value = $existing_value;
        } elseif ($value == 2) {
            $warning = true;
            $value   = $existing_value;
        }

        $return['value'] = $value;

        if ($error == true) {
            $field['msg']    = 'your custom error message';
            $return['error'] = $field;
        }

        if ($warning == true) {
            $field['msg']      = 'your custom warning message';
            $return['warning'] = $field;
        }

        return $return;
    }
}

/**
 * Custom function for the callback referenced above
 */
if (!function_exists('redux_my_custom_field')) {
    function redux_my_custom_field($field, $value)
    {
        print_r($field);
        echo '<br/>';
        print_r($value);
    }
}

/**
 * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
 * Simply include this function in the child themes functions.php file.
 * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
 * so you must use get_template_directory_uri() if you want to use any of the built in icons
 * */
if (!function_exists('dynamic_section')) {
    function dynamic_section($sections)
    {
        //$sections = array();
        $sections[] = array(
            'title'  => __('Section via hook', 'redux-framework-demo'),
            'desc'   => __('<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'redux-framework-demo'),
            'icon'   => 'el el-paper-clip',
            // Leave this as a blank section, no options just some intro text set above.
            'fields' => array()
        );

        return $sections;
    }
}

/**
 * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
 * */
if (!function_exists('change_arguments')) {
    function change_arguments($args)
    {
        //$args['dev_mode'] = true;

        return $args;
    }
}

/**
 * Filter hook for filtering the default value of any given field. Very useful in development mode.
 * */
if (!function_exists('change_defaults')) {
    function change_defaults($defaults)
    {
        $defaults['str_replace'] = 'Testing filter hook!';

        return $defaults;
    }
}

/**
 * Removes the demo link and the notice of integrated demo from the redux-framework plugin
 */
if (!function_exists('remove_demo')) {
    function remove_demo()
    {
        // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
        if (class_exists('ReduxFrameworkPlugin')) {
            remove_filter('plugin_row_meta', array(
                ReduxFrameworkPlugin::instance(),
                'plugin_metalinks'
            ), null, 2);

            // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
            remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
        }
    }
}
