<?php get_header(); ?>
<?php global $prothom_alo; ?>

<section class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
			<div class="Keywords_ground">
				<b>Keywords :</b>
				<p><?php the_search_query(); ?></p>
			</div>
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="search_item_part">
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<p><?php the_excerpt_max_charlength(170); ?></p>
					</div>
				<?php endwhile;
			else : ?>
				<p><?php _e('Sorry, but nothing matched your search terms. Please try again with some different keywords'); ?></p>
			<?php endif; ?>
			<h3 class="search_image_title">ছবি</h3>
			<div class="search_tum_part">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<a href="<?php the_permalink(); ?>">
							<?php if (has_post_thumbnail()) {
								the_post_thumbnail('thumbnail');
							} else {
								echo '<img width="100" height="100" src="' . get_bloginfo('template_url') . '/img/tiger.jpg" class="ashit" alt="Default image" />';
							} ?>
						<?php endwhile;
				else : ?>
						<p><?php _e('Sorry, but nothing matched your search terms. Please try again with some different keywords'); ?></p>
					<?php get_search_form();
				endif; ?>
						</a>

			</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
			<?php get_sidebar(); ?>

			<div class="categories_ground">
				<h5><?php _e('বিভাগ'); ?></h5>
				<?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?>
				<h5><?php _e('মাস-বছর'); ?></h5>
				<div class="years_month_ground">
					<?php wp_get_archives('type=monthly'); ?>
				</div>

			</div>

		</div>
	</div>
</section>


<?php get_footer(); ?>