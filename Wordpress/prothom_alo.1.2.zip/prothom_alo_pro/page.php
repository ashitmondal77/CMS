<?php global $prothom_alo; ?>
<?php get_header(); ?>

<section class="single_page_ground_part1">
    <div class="custom-container">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <div class="Breadcrumbs_ground">
                    <a href="<?php home_ento(); ?>"><i class="fa fa-home"></i></a> › <?php the_category(' › ') ?>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                        <div class="athor_shere_ground">
                            <div class="athor_shere_sizing">
                                <?php the_author(); ?>
                            </div>
                            <div class="athor_shere_sizing">
                                <d><b> আজ :</b> <?php echo do_shortcode('[english_date]'); ?>, <?php echo do_shortcode('[bangla_date]'); ?>, <?php echo do_shortcode('[bangla_day]'); ?></d>

                                <d><b>প্রকাশ করা : </b><?php echo get_the_date(); ?></d>
                            </div>
                            <div class="athor_shere_sizing">
                                <li class="athor_shere_print"><a onclick="window.print()"><i class="fas fa-print sh_size"></i></a></li>
                                <li class="athor_shere_facebook"><a href=" #"><i class="fab fa-facebook-f sh_size"></i></a></li>
                                <li class="athor_shere_twitter"><a href="#"><i class="fab fa-twitter sh_size"></i></a></li>
                                <li class="athor_shere_linkin"><a href="#"><i class="fab fa-linkedin-in sh_size"></i></a></li>
                                <li class="athor_shere_whatsapp"><a href="#"><i class="fab fa-whatsapp sh_size"></i></a></li>
                                </br>
                            </div>
                            <div class="athor_shere_sizing">
                                <h6><?php comments_number('কোন মন্তব্য নেই', '1 মন্তব্য', '% মন্তব্য'); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        <div class="single_title_ground">
                            <h1><?php the_title(); ?></h1>
                        </div>
                        <?php the_content(); ?>
                        <?php comments_template(); ?>

                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <?php get_sidebar(); ?>
                    </div>
                </div>

            <?php endwhile; ?>
        <?php endif; ?>

    </div>
</section>




<?php get_footer(); ?>