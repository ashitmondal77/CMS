<?php global $prothom_alo;?>
<?php get_header(); ?>
<!----style code ues from single part---->
</br>
<?php echo $prothom_alo['sidebar_ads1']?>
</br></br>
<div class="single-post-list-ground">
   <?php $categories = get_the_category($post->ID);
   if ($categories) {
      $category_ids = array();
      foreach ($categories as $individual_category) $category_ids[] = $individual_category->term_id;
   }

   $args = array(
      'category__in' => $category_ids,
      'post__not_in' => array($post->ID),
      'showposts' => 4,
      'orderby' => 'rand',
      'ignore_sticky_posts' => 1
   ); ?>

   <?php $foodpost = new WP_Query($args); ?>
   <?php if ($foodpost->have_posts()) : while ($foodpost->have_posts()) : $foodpost->the_post(); ?>
         <a href="<?php the_permalink(); ?>">
            <ul class="list-unstyled all_post_cart_gropund">
               <li class="media">
                  <?php if (has_post_thumbnail()) {
                     the_post_thumbnail('small-thumbnail');
                  } else {
                     echo '<img width="100%" height="100%"src="' . get_bloginfo('template_url') . '/image/Pro_logo.jpg"  alt="ashit mondal" />';
                  } ?>
                  <div class="media-body">
                     <h2 class="mt-0 mb-1"><?php the_title(); ?></h2>
                  </div>
               </li>

            </ul>
         </a>
      <?php endwhile;
   else : ?>
   <?php endif; ?>
   
</div>
